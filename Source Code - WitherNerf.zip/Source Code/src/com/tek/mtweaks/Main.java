package com.tek.mtweaks;

import org.bukkit.plugin.java.JavaPlugin;

import com.tek.mtweaks.events.EntityDeathListener;
import com.tek.mtweaks.events.EntityExplodeListener;

public class Main extends JavaPlugin {
	
	@Override
	public void onEnable() {
		getServer().getPluginManager().registerEvents(new EntityExplodeListener(), this);
		getServer().getPluginManager().registerEvents(new EntityDeathListener(), this);
	}
	
}
