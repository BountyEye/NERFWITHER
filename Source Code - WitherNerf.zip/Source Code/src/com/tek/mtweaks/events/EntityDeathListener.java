package com.tek.mtweaks.events;

import java.util.Iterator;

import org.bukkit.Material;
import org.bukkit.entity.WitherSkeleton;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;

public class EntityDeathListener implements Listener {
	
	@EventHandler
	public void onEntityDeath(EntityDeathEvent event) {
		if(event.getEntity() instanceof WitherSkeleton) {
			Iterator<ItemStack> itemIterator = event.getDrops().iterator();
			ItemStack item;
			while(itemIterator.hasNext()) {
				item = itemIterator.next();
				if(item.getType().equals(Material.WITHER_SKELETON_SKULL)) {
					itemIterator.remove();
				}
			}
		}
	}
	
}
