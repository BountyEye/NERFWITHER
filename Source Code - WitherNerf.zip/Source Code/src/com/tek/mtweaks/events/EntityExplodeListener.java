package com.tek.mtweaks.events;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Wither;
import org.bukkit.entity.WitherSkull;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class EntityExplodeListener implements Listener {
	
	@EventHandler
	public void onEntityExplode(EntityExplodeEvent event) {
		if(event.getEntity() instanceof Wither) {
			event.blockList().clear();
			Block explosionBlock = event.getLocation().getBlock();
			event.blockList().addAll(getSphericalRange(explosionBlock, 5).stream()
					.filter(block -> block.getType().equals(Material.OBSIDIAN)).collect(Collectors.toList()));
		}
		
		if(event.getEntity() instanceof WitherSkull) {
			event.blockList().clear();
			Block explosionBlock = event.getLocation().getBlock();
			event.blockList().addAll(getSphericalRange(explosionBlock, 2.5).stream()
					.filter(block -> block.getType().equals(Material.OBSIDIAN)).collect(Collectors.toList()));
		}
	}
	
	public List<Block> getSphericalRange(Block center, double radius) {
		List<Block> blocks = new ArrayList<Block>();
		Block blockAt;
		double distance;
		for(int x = (int) Math.floor(-radius); x <= Math.ceil(radius); x++) {
			for(int y = (int) Math.floor(-radius); y <= Math.ceil(radius); y++) {
				for(int z = (int) Math.floor(-radius); z <= Math.ceil(radius); z++) {
					blockAt = center.getLocation().add(x, y, z).getBlock();
					distance = center.getLocation().add(0.5, 0.5, 0.5)
							.distance(blockAt.getLocation().add(0.5, 0.5, 0.5));
					if(distance <= radius) blocks.add(blockAt);
				}
			}
		}
		return blocks;
	}
	
}
